package case2;

public class AlertLevel {
    public final static int HIGH = 1;
    public final static int NORMAL = 0;
    public final static int LOW = -1;
}
